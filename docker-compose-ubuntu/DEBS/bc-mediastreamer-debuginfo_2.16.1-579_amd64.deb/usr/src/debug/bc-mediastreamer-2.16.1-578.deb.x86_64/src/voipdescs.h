#include "mediastreamer2/msfilter.h"

MS2_VAR_PUBLIC MSFilterDesc ms_alaw_dec_desc;
MS2_VAR_PUBLIC MSFilterDesc ms_alaw_enc_desc;
MS2_VAR_PUBLIC MSFilterDesc ms_audio_mixer_desc;
MS2_VAR_PUBLIC MSFilterDesc ms_channel_adapter_desc;
MS2_VAR_PUBLIC MSFilterDesc ms_dtmf_gen_desc;
MS2_VAR_PUBLIC MSFilterDesc ms_equalizer_desc;
MS2_VAR_PUBLIC MSFilterDesc ms_audio_flow_control_desc;
MS2_VAR_PUBLIC MSFilterDesc ms_genericplc_desc;
MS2_VAR_PUBLIC MSFilterDesc ms_l16_dec_desc;
MS2_VAR_PUBLIC MSFilterDesc ms_l16_enc_desc;
MS2_VAR_PUBLIC MSFilterDesc ms_file_player_desc;
MS2_VAR_PUBLIC MSFilterDesc ms_file_rec_desc;
MS2_VAR_PUBLIC MSFilterDesc ms_g722_dec_desc;
MS2_VAR_PUBLIC MSFilterDesc ms_g722_enc_desc;
MS2_VAR_PUBLIC MSFilterDesc ms_vad_dtx_desc;
MS2_VAR_PUBLIC MSFilterDesc ms_volume_desc;
MS2_VAR_PUBLIC MSFilterDesc ms_tone_detector_desc;
MS2_VAR_PUBLIC MSFilterDesc ms_ulaw_dec_desc;
MS2_VAR_PUBLIC MSFilterDesc ms_ulaw_enc_desc;
MS2_VAR_PUBLIC MSFilterDesc ms_rtp_send_desc;
MS2_VAR_PUBLIC MSFilterDesc ms_rtp_recv_desc;
MS2_VAR_PUBLIC MSFilterDesc ms_rtt_4103_source_desc;
MS2_VAR_PUBLIC MSFilterDesc ms_rtt_4103_sink_desc;
MS2_VAR_PUBLIC MSFilterDesc ms_udp_send_desc;
MS2_VAR_PUBLIC MSFilterDesc alsa_write_desc;
MS2_VAR_PUBLIC MSFilterDesc alsa_read_desc;
MS2_VAR_PUBLIC MSFilterDesc ms_resample_desc;
MS2_VAR_PUBLIC MSFilterDesc ms_speex_ec_desc;
MSFilterDesc * ms_voip_filter_descs[]={
&ms_alaw_dec_desc,
&ms_alaw_enc_desc,
&ms_audio_mixer_desc,
&ms_channel_adapter_desc,
&ms_dtmf_gen_desc,
&ms_equalizer_desc,
&ms_audio_flow_control_desc,
&ms_genericplc_desc,
&ms_l16_dec_desc,
&ms_l16_enc_desc,
&ms_file_player_desc,
&ms_file_rec_desc,
&ms_g722_dec_desc,
&ms_g722_enc_desc,
&ms_vad_dtx_desc,
&ms_volume_desc,
&ms_tone_detector_desc,
&ms_ulaw_dec_desc,
&ms_ulaw_enc_desc,
&ms_rtp_send_desc,
&ms_rtp_recv_desc,
&ms_rtt_4103_source_desc,
&ms_rtt_4103_sink_desc,
&ms_udp_send_desc,
&alsa_write_desc,
&alsa_read_desc,
&ms_resample_desc,
&ms_speex_ec_desc,
NULL
};

